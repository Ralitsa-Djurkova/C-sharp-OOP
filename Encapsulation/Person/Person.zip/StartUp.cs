﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PersonsInfo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            var person = new Person("Valeri", "Bojinoc", 30, 20000);
            var team = new Team("Botev Vratsa");
            team.AddPlayer(person);
            team.AddPlayer(new Person("Mario", "Milushev", 45, 1000));

            Console.WriteLine(team.FirstTeam.Count);
            Console.WriteLine(team.SecondTeam.Count);
        }
    }
}
