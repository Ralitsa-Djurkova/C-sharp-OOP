﻿

namespace ShoppingSpree.Common
{
    public class GlobalConstants
    {
        public const string EmptyNameExMsg = "Name cannot be empty";
        public const string NegativeMoneyExMsg = "Money cannot be negative";
    }
}
